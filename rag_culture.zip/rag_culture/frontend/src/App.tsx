import React, { useState } from 'react';
import { Layout, Input, Button, Card, message, Typography } from 'antd';
import { SendOutlined } from '@ant-design/icons';
import axios from 'axios';
import './App.css';

const { Header, Content } = Layout;
const { Title, Paragraph } = Typography;
const { TextArea } = Input;

const App: React.FC = () => {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!question.trim()) {
      message.warning('请输入您的问题');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post('http://localhost:8000/api/query', {
        question: question
      });
      
      setAnswer(response.data.answer);
    } catch (error) {
      message.error('获取答案失败，请稍后重试');
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout className="layout">
      <Header className="header">
        <Title level={2} style={{ color: 'white', margin: 0 }}>
          智能RAG问答系统
        </Title>
      </Header>
      <Content className="content">
        <Card className="main-card">
          <Paragraph>
            欢迎使用智能RAG问答系统。本系统基于先进的RAG（检索增强生成）技术，
            可以基于知识库回答您的问题。您可以询问任何关于系统知识库中的内容。
          </Paragraph>
          <div className="input-section">
            <TextArea
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="请输入您的问题..."
              autoSize={{ minRows: 3, maxRows: 6 }}
              className="question-input"
            />
            <Button
              type="primary"
              icon={<SendOutlined />}
              onClick={handleSubmit}
              loading={loading}
              className="submit-button"
            >
              提交问题
            </Button>
          </div>
          {answer && (
            <Card className="answer-card">
              <Title level={4}>回答：</Title>
              <Paragraph>{answer}</Paragraph>
            </Card>
          )}
        </Card>
      </Content>
    </Layout>
  );
};

export default App; 