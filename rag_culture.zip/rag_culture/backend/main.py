from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import requests
import os
from dotenv import load_dotenv
import bs4
from langchain import hub
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import WebBaseLoader
from langchain_community.vectorstores import Chroma
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_ollama import OllamaEmbeddings
from langchain_deepseek import ChatDeepSeek

load_dotenv()

app = FastAPI()

# 配置CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化RAG系统
def initialize_rag():
    # 加载文档
    loader = WebBaseLoader(
        web_paths=("https://lilianweng.github.io/posts/2023-06-23-agent/",),
        bs_kwargs=dict(
            parse_only=bs4.SoupStrainer(
                class_=("post-content", "post-title", "post-header")
            )
        ),
    )
    docs = loader.load()

    # 文本分割
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    splits = text_splitter.split_documents(docs)

    # 嵌入向量化
    vectorstore = Chroma.from_documents(
        documents=splits, 
        embedding=OllamaEmbeddings(model="nomic-embed-text")
    )

    # 创建检索器
    retriever = vectorstore.as_retriever()

    # 获取预定义的RAG提示模板
    prompt = hub.pull("rlm/rag-prompt")

    # 初始化DeepSeek聊天模型
    llm = ChatDeepSeek(
        model="deepseek-chat",
        temperature=0,
        max_tokens=None,
        timeout=None,
        max_retries=2,
    )

    # 后处理函数
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    # 构建RAG链
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    return rag_chain

# 初始化RAG系统
rag_chain = initialize_rag()

class QueryRequest(BaseModel):
    question: str

@app.get("/")
async def read_root():
    return {"message": "传统文化RAG问答系统已启动"}

@app.post("/api/query")
async def query_rag(request: QueryRequest):
    try:
        # 使用RAG链处理问题
        answer = rag_chain.invoke(request.question)
        return {"answer": answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 